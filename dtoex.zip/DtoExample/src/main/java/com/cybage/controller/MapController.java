package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.entity.LocationDTO;
import com.cybage.entity.UserLocationDTO;
import com.cybage.service.MapService;
import com.example.model.Users;
import com.fasterxml.jackson.annotation.JacksonInject.Value;

@RestController
public class MapController {
	@Autowired MapService mapService;
	

	@GetMapping()
	public String getString(){
		return "successful get request";
	}
//	<!-- https://mvnrepository.com/artifact/org.modelmapper/modelmapper -->
//	<dependency>
//	    <groupId>org.modelmapper</groupId>
//	    <artifactId>modelmapper</artifactId>
//	    <version>2.3.8</version>
//	</dependency>
	@GetMapping("/get")
	@ResponseBody
	public List<UserLocationDTO> getAllUsersLocation() {
		List<UserLocationDTO> userLocation=mapService.getAllUsersLocation();
		return userLocation;
	}
	
	@GetMapping(value ="get/{id}")
	@ResponseBody
	public UserLocationDTO getUserLocation(@PathVariable("id") Long id) {
		return mapService.getUserLocation(id);
	}
    @GetMapping(value = "get/allLocations")
    @ResponseBody
    public List<LocationDTO> getAllLocations() {
    	List <LocationDTO> locations = mapService.getAllLocations();
    	return locations;
    }
    @PostMapping(value = "/addLocation")
    @ResponseStatus(HttpStatus.OK)
    public void addLocation(@RequestBody LocationDTO locationDTO) {    
    	mapService.addLocation(locationDTO);
    }
    
//	@PutMapping("users/{id}")
//	public String updateUsers(@RequestBody Users user, @PathVariable int id){
//		users.removeIf(u -> u.getId() == id);
//		users.add(user);
//		return "successfully updated record: "+ user;
//	}
	@DeleteMapping("deleteLocDto/{id}")
	public String deleteLocationDTO(@PathVariable int id){
    	List <LocationDTO> locations = mapService.getAllLocations();
    	
		//users.removeIf(u -> u.getId() == id);
		return "successfully deleted record: " +id;
	}
}
