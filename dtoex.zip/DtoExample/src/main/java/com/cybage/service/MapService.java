package com.cybage.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.entity.Location;
import com.cybage.entity.LocationDTO;
import com.cybage.entity.User;
import com.cybage.entity.UserLocationDTO;
import com.cybage.repository.LocationRepository;
import com.cybage.repository.UserRepository;

@Service
public class MapService {
	@Autowired
	private LocationRepository locationRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private ModelMapper modelMapper;
	
	public UserLocationDTO getUserLocation(Long id) {
		return convertToUserLocationDTO(userRepository.findById(id).get());
	}
	
	public List<UserLocationDTO> getAllUsersLocation(){
		return ((List<User>)userRepository
				.findAll())
				.stream()
				.map(this::convertToUserLocationDTO)
				.collect(Collectors.toList());
	}
	
	public List<LocationDTO> getAllLocations(){
		return ((List<Location>) locationRepository.findAll())
				.stream()
				.map(obj -> modelMapper.map(obj, LocationDTO.class))
				.collect(Collectors.toList());
	}

	public void addLocation(LocationDTO locationDto) {
		Location location = new ModelMapper().map(locationDto, Location.class);
		locationRepository.save(location);
	}
	
	
	//using object mapper class
	private UserLocationDTO convertToUserLocationDTO(User user) { 
		modelMapper.getConfiguration()
			.setMatchingStrategy(MatchingStrategies.LOOSE);
		UserLocationDTO userLocationDTO=modelMapper
				.map(user, UserLocationDTO.class);
		return userLocationDTO;
	}
	
	//manual
//	private UserLocationDTO convertToUserLocationDTO(User user) {
//		UserLocationDTO userLocationDTO =new UserLocationDTO();
//		userLocationDTO.setUserId(user.getId());
//		userLocationDTO.setUsername(user.getUsername());
//		Location location=user.getLocation();
//		userLocationDTO.setLat(location.getLat());
//		userLocationDTO.setLng(location.getLng());
//        userLocationDTO.setPlace(location.getPlace());
//        return userLocationDTO; 
//	}
	

}
