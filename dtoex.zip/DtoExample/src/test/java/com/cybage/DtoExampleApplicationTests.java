package com.cybage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DtoExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
